import sys
import signal

TIMEOUT = 1 # seconds
signal.signal(signal.SIGALRM, input)
signal.alarm(TIMEOUT)

print("Inicio")
print("Script Python\n")

try:
	nombre = sys.argv[1]
	print(f"Hola {nombre}!\n")
except:
	ignorar = True

print("Fin")

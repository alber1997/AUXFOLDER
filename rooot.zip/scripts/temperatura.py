import sys
import signal

TIMEOUT = 1 # seconds
signal.signal(signal.SIGALRM, input)
signal.alarm(TIMEOUT)

print("Inicio")
print("Script Python\n")

try:
    entrada = sys.stdin.readline().strip()
    temperatura_celsius = float(entrada)
    fahrenheit = (temperatura_celsius * 9/5) + 32
    print(f"{temperatura_celsius}°C son {fahrenheit}°F\n")
except:
    ignorar = True


print("\n\nFin del script")
